<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">

      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3>Why choose us?</h3>
         <p>Welcome to Learn Lattice, where academic excellence meets personalized guidance. Our team of expert tutors is dedicated to understanding your unique learning style, providing tailored support in flexible virtual classrooms equipped with interactive tools. Whether you're a student preparing for exams or a professional seeking new skills, our platform adapts to your schedule. With a track record of proven results, we go beyond subject-specific tutoring, offering holistic support in study skills and exam preparation. Transparent communication ensures a collaborative and successful learning journey. Join Learn Lattice today for a personalized, effective, and flexible approach to achieving your academic goals.</p>
         <a href="courses.php" class="inline-btn">Our courses</a>
      </div>

   </div>

   <div class="box-container">

      <div class="box">
         <i class="fas fa-graduation-cap"></i>
         <div>
            <h3>+1k</h3>
            <span>Online Courses</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-user-graduate"></i>
         <div>
            <h3>+25k</h3>
            <span>Brilliants Students</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-chalkboard-user"></i>
         <div>
            <h3>+5k</h3>
            <span>Expert Teachers</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-briefcase"></i>
         <div>
            <h3>100%</h3>
            <span>Job Placement</span>
         </div>
      </div>

   </div>

</section>

<!-- about section ends -->

<!-- reviews section starts  -->

<section class="reviews">

   <h1 class="heading">Student's Reviews</h1>

   <div class="box-container">

      <div class="box">
         <p>I can't thank Learn Lattice enough for their incredible support. The tutors are not just knowledgeable but also incredibly patient. The flexible scheduling allowed me to manage my time effectively, and the interactive online platform made learning engaging. My grades have improved, and I feel more confident in my studies.</p>
         <div class="user">
            <img src="images/pic-2.jpg" alt="">
            <div>
               <h3>Sarah T.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Choosing Learn Lattice was a game-changer for me. The expert tutors went above and beyond to understand my learning needs, making each session personalized and effective. The virtual classrooms are user-friendly, and the tools provided made learning enjoyable. I highly recommend it to anyone seeking quality tutoring.</p>
         <div class="user">
            <img src="images/pic-3.jpg" alt="">
            <div>
               <h3>Alex G.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>I was struggling with math, but Learn Lattice turned things around. The tutors not only helped me grasp difficult concepts but also taught me effective study strategies. The transparent communication between tutors and parents kept everyone informed, fostering a collaborative learning environment. I'm now confident in my math abilities, all thanks to this fantastic platform.</p>
         <div class="user">
            <img src="images/pic-4.jpg" alt="">
            <div>
               <h3>Emily R.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>The holistic support at Learn Lattice is unmatched. It's not just about grades; they genuinely care about your overall learning experience. The tutors not only helped me with chemistry but also provided valuable advice on time management. The results speak for themselves, and I'm grateful for the well-rounded education I received.</p>
         <div class="user">
            <img src="images/pic-5.jpg" alt="">
            <div>
               <h3>Jake M.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>I was hesitant about online tutoring, but Learn Lattice exceeded my expectations. The interactive tools in the virtual classrooms make learning dynamic and interesting. The flexible scheduling allowed me to balance my studies with other commitments. The tutors are friendly, approachable, and genuinely invested in your success.</p>
         <div class="user">
            <img src="images/pic-6.jpg" alt="">
            <div>
               <h3>Sophie L.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>As a working professional, finding time for learning is challenging. Learn Lattice made it possible. The flexible scheduling and virtual classrooms allowed me to upskill without disrupting my work. The expert tutors not only helped me understand complex concepts but also provided practical insights relevant to my field. A fantastic resource for lifelong learners.</p>
         <div class="user">
            <img src="images/pic-7.jpg" alt="">
            <div>
               <h3>Daniel K.</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

   </div>

</section>

<!-- reviews section ends -->

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>