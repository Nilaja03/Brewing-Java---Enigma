<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>Brewing Java</span> | All rights reserved!

</footer>